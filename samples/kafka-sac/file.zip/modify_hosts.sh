#!/bin/bash
sed -i '$d' /etc/hosts
