#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <memory>
#include "message.h"
#include "json-cpp.hpp"
#include "print_utils.h"
#include "base64_utils.h"
#include "constants.h"
#include "string.h"
#include <chrono>
#include <map>
#include <mutex>

#include <zmq.hpp>
#include <unistd.h>

#include "sgx_urts.h"
#include "enclave_u.h"
#include "sgx_ukey_exchange.h"

#define ENCLAVE_PATH "enclave.signed.so"

#ifndef DEMO_VARIABLE
#define DEMO_VARIABLE 1
#endif

#ifndef SAFE_FREE
#define SAFE_FREE(ptr) {if (NULL != (ptr)) {free(ptr); (ptr) = NULL;}}
#endif

#define _T(x) x

using namespace std;
using namespace std::chrono;

std::map<uint32_t, sgx_ra_context_t> contexts_map;
std::mutex contexts_map_mutex;

FILE* OUTPUT = stdout;
sgx_enclave_id_t eid;
bool attested = false;

/* OCALLs */
void print_byte_array( void *mem, size_t len )
{
    int i, count=0;
    uint8_t *array = ( uint8_t * ) mem;
    for ( i=0; i<len; i++ )
    {   
        if ( count == 0 ) printf( "\n" );
        count = ( count + 1 ) % 8;
        printf( "0x%x", array[i] );
        if ( i+1 < len ) printf( ", " );
    }   
    printf( "\n" );

}

void emit_debug( const char *dbg_message )
{
    printf( "\nEnclave: %s\n", dbg_message );
}

/* Utils */
void decode_ra_message_payload( message_t *p_ra_message, uint8_t **pp_decoded_payload, size_t *p_decoded_size)
{
    size_t encoded_size = p_ra_message->payload.size();
    char *encoded_payload = (char *) malloc(encoded_size);
    memset(encoded_payload, 0, encoded_size);
    memcpy(encoded_payload, p_ra_message->payload.c_str(), encoded_size);

    size_t decoded_size = encoded_size;
    uint8_t *decoded_payload = (uint8_t *) malloc(decoded_size);
    memset(decoded_payload, 0, decoded_size);

    base64decode(encoded_payload, encoded_size, decoded_payload, &decoded_size);

    *pp_decoded_payload = decoded_payload;
    *p_decoded_size = decoded_size;
}

void generate_ra_response_message( int message_type, void *p_payload, size_t payload_size, message_t *p_ra_response_message )
{
    size_t encoded_payload_size = payload_size * 2;
    char *encoded_payload = ( char * ) calloc( encoded_payload_size, 1 );

    base64encode( p_payload, payload_size, encoded_payload, encoded_payload_size );
    std::string encoded_payload_str( encoded_payload );

    message_t ra_response_message{ message_type, encoded_payload_str };

    *p_ra_response_message = ra_response_message;

    SAFE_FREE( p_payload );
    SAFE_FREE( encoded_payload );
}

void generate_msg1( message_t *p_ra_msg1, uint8_t *p_msg1, size_t response_size  )
{
    generate_ra_response_message( MSG1, p_msg1, response_size, p_ra_msg1 );
}

void generate_msg3( message_t *p_ra_msg3, uint8_t *p_msg3, size_t response_size  )
{
    generate_ra_response_message( MSG3, p_msg3, response_size, p_ra_msg3 );
}

/* Message handling */
sgx_status_t handle_ra_message_init_msg( message_t *p_ra_init_msg, message_t *p_ra_message_msg1 )
{
    sgx_status_t ret = SGX_SUCCESS, status = SGX_SUCCESS;

    size_t decoded_payload_size;
    uint8_t *p_decoded_payload = NULL;
    decode_ra_message_payload( p_ra_init_msg, &p_decoded_payload, &decoded_payload_size );

    sgx_ec256_public_t client_public_key;
    memset( &client_public_key, 0, sizeof( sgx_ec256_public_t ) );
    if ( decoded_payload_size != sizeof( sgx_ec256_public_t ) )
    {
        fprintf( OUTPUT, "\nError: RA_INIT message has an invalid payload. [%s]",
                 __FUNCTION__ );
        return SGX_ERROR_UNEXPECTED;
    }
    memcpy( &client_public_key, p_decoded_payload, decoded_payload_size );
    SAFE_FREE( p_decoded_payload );

    sgx_ra_context_t context;
    memset( &context, 0, sizeof( sgx_ra_context_t ) );

    ret = enclave_ra_init( eid, &status, &client_public_key, sizeof( sgx_ec256_public_t ), &context );

    if ( SGX_SUCCESS != status || SGX_SUCCESS != ret )
    {
        fprintf( OUTPUT, "\nError: failed to execute enclave_ra_init function. [%s]\n",
                 __FUNCTION__ );
        print_error_message(status);
        return status;
    }

    sgx_ra_msg1_t msg1;
    ret = sgx_ra_get_msg1( context, eid, sgx_ra_get_ga, &msg1 );
    if ( SGX_SUCCESS != ret )
    {
        fprintf( OUTPUT, "\nError: unable to get MSG1 from enclave. [%s]",
                 __FUNCTION__ );
        return ret;
    }

    size_t response_size = sizeof( sgx_ra_msg1_t ) + sizeof( sgx_ra_context_t );
    uint8_t *p_response = ( uint8_t * ) calloc( response_size, 1 );
    memcpy( p_response, &msg1, sizeof( sgx_ra_msg1_t ) );
    memcpy( p_response + sizeof( sgx_ra_msg1_t ), &context, sizeof( sgx_ra_context_t ) );

    generate_msg1( p_ra_message_msg1, p_response, response_size );

    return ret;
}

sgx_status_t handle_ra_message_msg2( message_t *p_ra_message_msg2, message_t *p_ra_message_msg3 )
{
    sgx_status_t ret = SGX_SUCCESS, status = SGX_SUCCESS;

    size_t decoded_payload_size;
    uint8_t *p_decoded_payload = NULL;
    decode_ra_message_payload( p_ra_message_msg2, &p_decoded_payload, &decoded_payload_size );

    size_t msg2_size = decoded_payload_size - sizeof( sgx_ra_context_t );
    sgx_ra_msg2_t *p_msg2 = (sgx_ra_msg2_t *) calloc( msg2_size, 1 );
    memcpy( p_msg2, p_decoded_payload, msg2_size );

    sgx_ra_context_t context;
    memset( &context, 0, sizeof( sgx_ra_context_t ) );
    memcpy( &context, p_decoded_payload + msg2_size, sizeof( sgx_ra_context_t ) );

    uint32_t msg3_size;
    sgx_ra_msg3_t *p_msg3 = NULL;
    ret = sgx_ra_proc_msg2( context, eid,
                            sgx_ra_proc_msg2_trusted,
                            sgx_ra_get_msg3_trusted,
                            p_msg2,
                            sizeof( sgx_ra_msg2_t ),
                            &p_msg3,
                            &msg3_size
    );

    if ( SGX_SUCCESS != ret )
    {
        fprintf( OUTPUT, "\nUnable to process MSG2. [%s]\n",
                 __FUNCTION__ );
        print_error_message(ret);
        return ret;
    }

    size_t response_size = msg3_size + sizeof( sgx_ra_context_t );
    uint8_t *p_response = ( uint8_t * ) calloc( response_size, 1 );
    memcpy( p_response, p_msg3, msg3_size );
    memcpy( p_response + msg3_size, &context, sizeof( sgx_ra_context_t ) );

    generate_msg3( p_ra_message_msg3, p_response, response_size );
    SAFE_FREE( p_decoded_payload );
    SAFE_FREE( p_msg2 );
    SAFE_FREE( p_msg3 );

    return SGX_SUCCESS;
}

sgx_status_t handle_secret_msg( message_t *p_secret_msg, message_t *p_secret_response_message )
{
    return SGX_SUCCESS;
}

void remote_attestation_handler( string str_body, string& response )
{
    sgx_status_t ret = SGX_ERROR_INVALID_PARAMETER;
    message_t ra_message, ra_response_message;
    jsoncpp::parse( ra_message, str_body );
    if ( RA_INIT == ra_message.message_type)
    {
#ifdef DEMO_FLAG
        cout << "[Consumer] Received Source's public key." << endl;
#endif
        ret = handle_ra_message_init_msg( &ra_message, &ra_response_message );
#ifdef DEMO_FLAG
        cout << "[Consumer] Generated MSG1 (GID || consumer public key)..." << endl;
#endif
    }
    else if ( MSG2 == ra_message.message_type )
    {
#ifdef DEMO_FLAG
        cout << "[Consumer] Received MSG2 from Source..." << endl;
#endif
        ret = handle_ra_message_msg2( &ra_message, &ra_response_message );
#ifdef DEMO_FLAG
        cout << "[Consumer] Successfully verified MSG2 and generated MSG3 (QUOTE)..." << endl;
#endif
    }
    else if (CONFIRMATION == ra_message.message_type)
    {
#ifdef DEMO_FLAG
        cout << "[Consumer] Received IAS verification of QUOTE from Source..." << endl;
#endif
        attested = true;
        ret = SGX_SUCCESS;
    }
    if ( SGX_SUCCESS != ret )
    {
        fprintf( OUTPUT, "\n[Consumer] Something went wrong...\n" );
    }
    response = jsoncpp::to_string( ra_response_message );
#ifdef DEMO_FLAG
    cout << "[Consumer] Press [RETURN] to continue." << endl;
    getchar();
#endif
}

//void send_secret_handler( const shared_ptr< Session > session )
//{
//    const auto request = session->get_request( );
//
//    if ( request->get_header( "Content-Type", String::lowercase ) == "application/json" )
//    {
//        if ( request->has_header( "Content-Length" ) )
//        {
//            int length = request->get_header( "Content-Length", 0 );
//            session->fetch( length, [ ]( const shared_ptr< Session > session, const Bytes& )
//            {
//                sgx_status_t ret = SGX_ERROR_INVALID_PARAMETER;
//                const auto request = session->get_request( );
//                const auto body = request->get_body( );
//
//                message_t secret_message, secret_response_message;
//
//                std::string str_body( body.begin( ), body.end( ) );
//                jsoncpp::parse( secret_message, str_body );
//
//                if ( SECRET_MSG == secret_message.message_type)
//                {
//                    ret = handle_secret_msg( &secret_message, &secret_response_message );
//                }
//                if ( SGX_SUCCESS != ret )
//                {
//                    fprintf( OUTPUT, "\nBad request...\n" );
//                    session->close( BAD_REQUEST );
//                }
//
//                const auto response_body = jsoncpp::to_string( secret_response_message );
//                size_t response_body_len = response_body.size( );
//
//                session->set_header( "Accept", "application/json" );
//                session->set_header( "Host", "http://localhost" );
//                session->set_header( "Content-Type", "application/json" );
//                session->set_header( "Content-Length", std::to_string( response_body_len ) );
//
//                session->close( OK, response_body );
//            } );
//        }
//        else
//        {
//            session->close( BAD_REQUEST );
//        }
//    }   
//    else
//    {   
//        session->close( BAD_REQUEST );
//    }
//
//}

sgx_status_t create_enclave( sgx_enclave_id_t *p_eid )
{
    sgx_status_t ret = SGX_SUCCESS;
    int updated = 0;
    sgx_launch_token_t launch_token;

    memset( &launch_token, 0, sizeof( sgx_launch_token_t ) );
    ret = sgx_create_enclave( _T( ENCLAVE_PATH ),
                              SGX_DEBUG_FLAG,
                              &launch_token,
                              &updated,
                              p_eid, NULL );
    return ret;
}

/* SP main */
int main( int argc, char* argv[] )
{
    sgx_status_t ret = SGX_SUCCESS, status = SGX_SUCCESS;

    /* Create SGX Enclave */
    ret = create_enclave( &eid );
    if ( ret != SGX_SUCCESS )
    {
        fprintf( OUTPUT, "\nError, call sgx_create_enclave failed [%s].",
                 __FUNCTION__ );
        return 1;
    }

    // ZMQ
    zmq::context_t ra_context(1);
    zmq::socket_t attestationSocket(ra_context, ZMQ_REP);
    attestationSocket.bind("tcp://*:8888");

    while (!attested){
        std::string message = s_recv( attestationSocket ), response;
        remote_attestation_handler(message, response);
        s_send( attestationSocket, response );

        usleep(1000);
    }

    fprintf(OUTPUT, "\nRemote attestation completed!\n");
    
//    send_secret_resource->set_method_handler( "POST", { { "Accept", "application/json" }, { "Content-Type", "application/json" } }, &send_secret_handler );

    /* Cleaning up */
    sgx_destroy_enclave( eid );
    printf( "\nPress [RETURN] before exit...\n" );
    getchar( );

    return ret;
}
