#ifndef _ERROR_H_
#define _ERROR_H_

#define MK_ERROR(x)              (0x00000000|(x))

typedef enum _status_t
{
    SUCCESS                  = MK_ERROR(0x0000),

    ERROR_UNEXPECTED         = MK_ERROR(0x0001),      /* Unexpected error */
    ERROR_INVALID_PARAMETER  = MK_ERROR(0x0002),      /* The parameter is incorrect */
    ERROR_OUT_OF_MEMORY      = MK_ERROR(0x0003),      /* Not enough memory is available to complete this operation */
    ERROR_ENCLAVE_LOST       = MK_ERROR(0x0004),      /* Enclave lost after power transition or used in child process created by linux:fork() */
    ERROR_INVALID_STATE      = MK_ERROR(0x0005),      /* SGX API is invoked in incorrect order or state */

    ERROR_INVALID_FUNCTION   = MK_ERROR(0x1001),      /* The ecall/ocall index is invalid */
    ERROR_OUT_OF_TCS         = MK_ERROR(0x1003),      /* The enclave is out of TCS */
    ERROR_ENCLAVE_CRASHED    = MK_ERROR(0x1006),      /* The enclave is crashed */
    ERROR_ECALL_NOT_ALLOWED  = MK_ERROR(0x1007),      /* The ECALL is not allowed at this time, e.g. ecall is blocked by the dynamic entry table, or nested ecall is not allowed during initialization */
    ERROR_OCALL_NOT_ALLOWED  = MK_ERROR(0x1008),      /* The OCALL is not allowed at this time, e.g. ocall is not allowed during exception handling */
    ERROR_STACK_OVERRUN      = MK_ERROR(0x1009),      /* The enclave is running out of stack */

    ERROR_UNDEFINED_SYMBOL   = MK_ERROR(0x2000),      /* The enclave image has undefined symbol. */
    ERROR_INVALID_ENCLAVE    = MK_ERROR(0x2001),      /* The enclave image is not correct. */
    ERROR_INVALID_ENCLAVE_ID = MK_ERROR(0x2002),      /* The enclave id is invalid */
    ERROR_INVALID_SIGNATURE  = MK_ERROR(0x2003),      /* The signature is invalid */
    ERROR_NDEBUG_ENCLAVE     = MK_ERROR(0x2004),      /* The enclave is signed as product enclave, and can not be created as debuggable enclave. */
    ERROR_OUT_OF_EPC         = MK_ERROR(0x2005),      /* Not enough EPC is available to load the enclave */
    ERROR_NO_DEVICE          = MK_ERROR(0x2006),      /* Can't open SGX device */
    ERROR_MEMORY_MAP_CONFLICT= MK_ERROR(0x2007),      /* Page mapping failed in driver */
    ERROR_INVALID_METADATA   = MK_ERROR(0x2009),      /* The metadata is incorrect. */
    ERROR_DEVICE_BUSY        = MK_ERROR(0x200c),      /* Device is busy, mostly EINIT failed. */
    ERROR_INVALID_VERSION    = MK_ERROR(0x200d),      /* Metadata version is inconsistent between uRTS and sgx_sign or uRTS is incompatible with current platform. */
    ERROR_MODE_INCOMPATIBLE  = MK_ERROR(0x200e),      /* The target enclave 32/64 bit mode or sim/hw mode is incompatible with the mode of current uRTS. */
    ERROR_ENCLAVE_FILE_ACCESS = MK_ERROR(0x200f),     /* Can't open enclave file. */
    ERROR_INVALID_MISC        = MK_ERROR(0x2010),     /* The MiscSelct/MiscMask settings are not correct.*/

    ERROR_MAC_MISMATCH       = MK_ERROR(0x3001),      /* Indicates verification error for reports, sealed datas, etc */
    ERROR_INVALID_ATTRIBUTE  = MK_ERROR(0x3002),      /* The enclave is not authorized */
    ERROR_INVALID_CPUSVN     = MK_ERROR(0x3003),      /* The cpu svn is beyond platform's cpu svn value */
    ERROR_INVALID_ISVSVN     = MK_ERROR(0x3004),      /* The isv svn is greater than the enclave's isv svn */
    ERROR_INVALID_KEYNAME    = MK_ERROR(0x3005),      /* The key name is an unsupported value */

    ERROR_SERVICE_UNAVAILABLE       = MK_ERROR(0x4001),   /* Indicates aesm didn't response or the requested service is not supported */
    ERROR_SERVICE_TIMEOUT           = MK_ERROR(0x4002),   /* The request to aesm time out */
    ERROR_AE_INVALID_EPIDBLOB       = MK_ERROR(0x4003),   /* Indicates epid blob verification error */
    ERROR_SERVICE_INVALID_PRIVILEGE = MK_ERROR(0x4004),   /* Enclave has no privilege to get launch token */
    ERROR_EPID_MEMBER_REVOKED       = MK_ERROR(0x4005),   /* The EPID group membership is revoked. */
    ERROR_UPDATE_NEEDED             = MK_ERROR(0x4006),   /* SGX needs to be updated */
    ERROR_NETWORK_FAILURE           = MK_ERROR(0x4007),   /* Network connecting or proxy setting issue is encountered */
    ERROR_AE_SESSION_INVALID        = MK_ERROR(0x4008),   /* Session is invalid or ended by server */
    ERROR_BUSY                      = MK_ERROR(0x400a),   /* The requested service is temporarily not availabe */
    ERROR_MC_NOT_FOUND              = MK_ERROR(0x400c),   /* The Monotonic Counter doesn't exist or has been invalided */
    ERROR_MC_NO_ACCESS_RIGHT        = MK_ERROR(0x400d),   /* Caller doesn't have the access right to specified VMC */
    ERROR_MC_USED_UP                = MK_ERROR(0x400e),   /* Monotonic counters are used out */
    ERROR_MC_OVER_QUOTA             = MK_ERROR(0x400f),   /* Monotonic counters exceeds quota limitation */
    ERROR_KDF_MISMATCH              = MK_ERROR(0x4011),   /* Key derivation function doesn't match during key exchange */

} status_t;
#endif
