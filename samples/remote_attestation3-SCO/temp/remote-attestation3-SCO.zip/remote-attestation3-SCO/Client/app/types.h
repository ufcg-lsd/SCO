#ifndef _TYPES_H
#define _TYPES_H
#include <stdint.h>

#define HASH_SIZE 32
#define MAC_SIZE 16
#define CMAC_KEY_SIZE 16
#define KEYID_SIZE 32
#define CPUSVN_SIZE 16
#define REPORT_DATA_SIZE 64
#define ECP256_KEY_SIZE 32
#define NISTP_ECP256_KEY_SIZE (ECP256_KEY_SIZE/sizeof(uint32_t))

typedef uint8_t      key_128bit_t[16];
typedef uint8_t      mac_t[MAC_SIZE];
typedef key_128bit_t ra_key_128_t;
typedef uint32_t     ra_context_t;
typedef uint8_t      epid_group_id_t[4];
typedef uint8_t      ec_key_128bit_t[CMAC_KEY_SIZE];
typedef uint16_t     isv_svn_t;
typedef uint32_t     misc_select_t;
typedef uint16_t     prod_id_t;

typedef enum
{
    UNLINKABLE_SIGNATURE,
    LINKABLE_SIGNATURE                                                                                               
} quote_sign_type_t;

typedef struct _ec256_dh_shared_t
{
    uint8_t s[ECP256_KEY_SIZE];
} ec256_dh_shared_t; 

typedef struct _ec256_private_t                                                                                      
{
    uint8_t r[ECP256_KEY_SIZE];                                                                                      
} ec256_private_t; 

typedef struct _ec256_public_t                                                                                       
{
    uint8_t gx[ECP256_KEY_SIZE];                                                                                     
    uint8_t gy[ECP256_KEY_SIZE];                                                                                     
} ec256_public_t;

typedef struct _ec256_signature_t
{
    uint32_t x[NISTP_ECP256_KEY_SIZE];
    uint32_t y[NISTP_ECP256_KEY_SIZE];
} ec256_signature_t;

typedef struct _ps_sec_prop_desc                                                                                         
{                                                                                                                        
    uint8_t  ps_sec_prop_desc[256];                                                                                  
} ps_sec_prop_desc_t;

typedef struct _spid_t
{
    uint8_t             id[16];
} spid_t;

typedef struct _ra_msg1_t
{
    ec256_public_t       g_a;         /* the Endian-ness of Ga is Little-Endian */
    epid_group_id_t      gid;         /* the Endian-ness of GID is Little-Endian */
} ra_msg1_t;

typedef struct _ra_msg2_t
{
    ec256_public_t       g_b;         /* the Endian-ness of Gb is Little-Endian */
    spid_t               spid;
    uint16_t                 quote_type;  /* unlinkable Quote(0) or linkable Quote(1) in little endian*/
    uint16_t                 kdf_id;      /* key derivation function id in little endian. */
    ec256_signature_t    sign_gb_ga;  /* In little endian */
    mac_t                mac;         /* mac_smk(g_b||spid||quote_type||kdf_id||sign_gb_ga) */
    uint32_t                 sig_rl_size;
    uint8_t                  sig_rl[];
} ra_msg2_t;

typedef struct _ra_msg3_t
{
    mac_t                mac;         /* mac_smk(g_a||ps_sec_prop||quote) */
    ec256_public_t       g_a;         /* the Endian-ness of Ga is Little-Endian */
    ps_sec_prop_desc_t   ps_sec_prop;
    uint8_t              quote[];
} ra_msg3_t;

typedef struct _basename_t
{
    uint8_t             name[32];
} basename_t;

typedef struct _cpu_svn_t
{
    uint8_t svn[CPUSVN_SIZE];
} cpu_svn_t;

typedef struct _attributes_t
{
    uint64_t      flags;
    uint64_t      xfrm;
} attributes_t;

typedef struct _key_id_t
{
    uint8_t id[KEYID_SIZE];
} key_id_t;

typedef struct _measurement_t
{
    uint8_t                 m[HASH_SIZE];
} measurement_t;

typedef struct _report_data_t
{
    uint8_t                 d[REPORT_DATA_SIZE];
} report_data_t;


typedef struct _report_body_t
{
    cpu_svn_t           cpu_svn;        /* (  0) Security Version of the CPU */
    misc_select_t       misc_select;    /* ( 16) Which fields defined in SSA.MISC */
    uint8_t             reserved1[28];  /* ( 20) */
    attributes_t        attributes;     /* ( 48) Any special Capabilities the Enclave possess */
    measurement_t       mr_enclave;     /* ( 64) The value of the enclave's ENCLAVE measurement */
    uint8_t             reserved2[32];  /* ( 96) */
    measurement_t       mr_signer;      /* (128) The value of the enclave's SIGNER measurement */
    uint8_t             reserved3[96];  /* (160) */
    prod_id_t           isv_prod_id;    /* (256) Product ID of the Enclave */
    isv_svn_t           isv_svn;        /* (258) Security Version of the Enclave */
    uint8_t             reserved4[60];  /* (260) */
    report_data_t       report_data;    /* (320) Data provided by the user */
} report_body_t;


typedef struct _report_t                    /* 432 bytes */
{
    report_body_t       body;
    key_id_t            key_id;         /* (384) KeyID used for diversifying the key tree */
    mac_t               mac;            /* (416) The Message Authentication Code over this structure. */
} report_t;

typedef struct _quote_t
{
    uint16_t        version;        /* 0   */
    uint16_t        sign_type;      /* 2   */
    epid_group_id_t epid_group_id;  /* 4   */
    isv_svn_t       qe_svn;         /* 8   */
    isv_svn_t       pce_svn;        /* 10  */
    uint32_t        xeid;           /* 12  */
    basename_t      basename;       /* 16  */
    report_body_t   report_body;    /* 48  */
    uint32_t        signature_len;  /* 432 */
    uint8_t         signature[];    /* 436 */
} quote_t;
#endif // _TYPES_H
