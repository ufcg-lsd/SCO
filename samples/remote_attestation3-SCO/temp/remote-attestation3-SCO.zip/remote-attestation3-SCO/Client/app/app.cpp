#include <stdio.h>
#include <stdlib.h>
#include "keys.h"
#include "types.h"
#include "message.h"
#include "json-cpp.hpp"
#include "print_utils.h"
#include "constants.h"
#include "conversions.h"
#include <curl/curl.h>
#include <chrono>
#include <thread>
#include <iostream>
#include <vector>
#include <zmq.hpp>
#include <unistd.h>

#include <eccrypto.h>
#include <oids.h>
#include <sha.h>
#include <osrng.h>
#include <hex.h>
#include <aes.h>
#include <cmac.h>
#include <secblock.h>
#include <files.h>
#include <filters.h>

#define CERT_PATH "clientconc.pem" // Define here the path to the certificate you used to register at IAS.
#define PRIVATE_KEY_SIZE 32
#define PUBLIC_KEY_SIZE (PRIVATE_KEY_SIZE * 2)
#define MAC_KEY_SIZE 16
#define EC_DERIVATION_BUFFER_SIZE(label_length) ((label_length) +4)

#ifndef SAFE_FREE
#define SAFE_FREE(ptr) {if (NULL != (ptr)) {free(ptr); (ptr) = NULL;}}
#endif

#define _T(x) x

using namespace std;
using namespace CryptoPP::ASN1;
using namespace CryptoPP;
using std::chrono::seconds;

string HexDecode(const string& data);

// Set here the SPID that you received from IAS.
// E.g.: if the SPID received was "00112233445566778899AABBCCDDEEFF", the SPID would be as below:
uint8_t smart_meter_spid[SPID_SIZE] = {     
	0xCB, 0x83, 0x1C, 0xE1,     
	0x94, 0xA3, 0x73, 0x33,     
	0x69, 0x57, 0x5A, 0xE6,     
	0xE6, 0xE9, 0xDB, 0xEE 
};

FILE* OUTPUT = stdout;

// All keys here in little endian!!!!!!!!!!!!!!!!
keys_db_item_t keys_db;

// All keys here in big endian!!!!!!!!!!!!!!!!
ECDSA<ECP, SHA256>::PrivateKey privateKeyBigEndian;
SecByteBlock privateKeyClientBlock;

/* Crypto functions */

void generateKeyPair( )
{
    AutoSeededRandomPool prng;
    std::string encPrivKey, encPubKey;

    OID oid = secp256r1();
    ECDH<ECP>::Domain ecdh(oid);

    SecByteBlock privKey(ecdh.PrivateKeyLength()), pubKey(ecdh.PublicKeyLength());
    ecdh.GenerateKeyPair(prng, privKey, pubKey);
    privateKeyClientBlock = privKey;

    HexEncoder encoder, encoderPub;
    HexDecoder decoder;
    encoder.Put(privKey, privKey.size());
    encoder.MessageEnd( );

    size_t encPrivKeySize = encoder.MaxRetrievable( );
    if ( encPrivKeySize )
    {
        encPrivKey.resize( encPrivKeySize );
        encoder.Get( ( byte * ) encPrivKey.data( ), encPrivKeySize );
    }
    
    uint8_t *p_privKey;
    hexstrToByteArray( encPrivKey.c_str( ), encPrivKeySize, &p_privKey );
    reverse(p_privKey, encPrivKeySize/2);
    memcpy( &keys_db.b, p_privKey, encPrivKeySize/2 );
    SAFE_FREE( p_privKey );
    decoder.Put( ( byte * ) encPrivKey.data( ), encPrivKey.size( ) );
    decoder.MessageEnd( );

    Integer x;
    x.Decode( decoder, decoder.MaxRetrievable( ) );
    privateKeyBigEndian.Initialize( secp256r1( ), x );

    encoderPub.Put( pubKey, pubKey.size() );
    encoderPub.MessageEnd();

    size_t encPubKeySize = encoderPub.MaxRetrievable();
    if ( encPubKeySize )
                                                                                                
    {
        encPubKey.resize( encPubKeySize );
        encoderPub.Get( ( byte * ) encPubKey.data( ), encPubKeySize );
    }
    uint8_t *p_pubKey;
    encPubKeySize -= 2;
    hexstrToByteArray( encPubKey.c_str( )+2, encPubKeySize, &p_pubKey );                                                
    reverse(p_pubKey, PUBLIC_KEY_SIZE/2);
    reverse(p_pubKey+PUBLIC_KEY_SIZE/2, PUBLIC_KEY_SIZE/2);
    memcpy( &keys_db.g_b, p_pubKey, PUBLIC_KEY_SIZE );                                                                   
    SAFE_FREE( p_pubKey );
}

/* Helper functions */
void generate_ra_message( int message_type, void *p_payload, size_t payload_size, message_t *p_ra_request_message)
{
    size_t encoded_payload_size = payload_size * 2;
    char *encoded_payload = (char *) malloc(encoded_payload_size);
    memset(encoded_payload, 0, encoded_payload_size);

    base64encode(p_payload, payload_size, encoded_payload, encoded_payload_size);
    std::string encoded_payload_str(encoded_payload);

    message_t ra_response_message{ message_type, encoded_payload_str };

    *p_ra_request_message = ra_response_message;
    SAFE_FREE(encoded_payload);
}


void generate_ra_init_message( ec256_public_t *p_client_public_key, message_t *p_ra_init_message )
{
    generate_ra_message( RA_INIT, p_client_public_key, sizeof( ec256_public_t ), p_ra_init_message );
}

void generate_msg2_message( ra_msg2_t *p_msg2, uint32_t msg2_size, ra_context_t *p_context, message_t *p_ra_msg2_message )
{
    uint8_t *p_msg2_context = ( uint8_t * ) calloc( msg2_size + sizeof( ra_context_t ), 1 );
    memcpy( p_msg2_context, p_msg2, msg2_size );
    memcpy( p_msg2_context + msg2_size, p_context, sizeof( ra_context_t ) );

    generate_ra_message( MSG2, p_msg2_context, msg2_size + sizeof( ra_context_t ), p_ra_msg2_message );
    SAFE_FREE(p_msg2_context);
}

void generate_confirmation_message( bool ra_result, ra_context_t *p_context, message_t *p_ra_confirmation_message )
{
    uint8_t *p_confirmation_context = (uint8_t *) calloc (sizeof(bool) + sizeof( ra_context_t ), 1);
    mempcpy( p_confirmation_context, &ra_result, sizeof(bool) );
    memcpy( p_confirmation_context+sizeof(bool), p_context, sizeof( ra_context_t ) );
    generate_ra_message( CONFIRMATION, p_confirmation_context, sizeof(bool) + sizeof( ra_context_t ), p_ra_confirmation_message );
    SAFE_FREE(p_confirmation_context);
}

void decode_ra_message_payload( message_t *p_ra_message, uint8_t **pp_decoded_payload, size_t *p_decoded_size)
{
    size_t encoded_size = p_ra_message->payload.size();
    char *encoded_payload = (char *) malloc(encoded_size);
    memset(encoded_payload, 0, encoded_size);
    memcpy(encoded_payload, p_ra_message->payload.c_str(), encoded_size);

    size_t decoded_size = encoded_size;
    uint8_t *decoded_payload = (uint8_t *) malloc(decoded_size);
    memset(decoded_payload, 0, decoded_size);

    base64decode(encoded_payload, encoded_size, decoded_payload, &decoded_size);

    *pp_decoded_payload = decoded_payload;
    *p_decoded_size = decoded_size;
}

status_t retrieve_message_from_response( string response, message_t *p_ra_msg )
{
    message_t ra_challenge_msg;
    jsoncpp::parse( ra_challenge_msg, response );
    *p_ra_msg = ra_challenge_msg;
    return SUCCESS;
}

status_t retrieve_msg1_from_response( string response, ra_msg1_t *p_msg1, ra_context_t *p_context )
{
    status_t ret = SUCCESS;

    message_t ra_msg1;
    ret = retrieve_message_from_response( response, &ra_msg1 );
    if ( SUCCESS != ret ) return ret;

    if ( ra_msg1.message_type != MSG1 ) return ERROR_UNEXPECTED;

    size_t decoded_payload_size;
    uint8_t *p_decoded_payload = NULL;

    decode_ra_message_payload( &ra_msg1, &p_decoded_payload, &decoded_payload_size );

    memcpy( p_msg1, p_decoded_payload, sizeof( ra_msg1_t ) );
    memcpy( p_context, p_decoded_payload + sizeof( ra_msg1_t ), sizeof( ra_context_t ) );
    return ret;
}

status_t retrieve_msg3_from_response( string response, ra_msg3_t **pp_msg3, uint32_t *p_msg3_size, ra_context_t *p_context )
{
    status_t ret = SUCCESS;

    message_t ra_msg3;
    ret = retrieve_message_from_response( response, &ra_msg3 );
    if ( SUCCESS != ret ) return ret;

    if ( ra_msg3.message_type != MSG3 ) return ERROR_UNEXPECTED;

    size_t decoded_payload_size;
    uint8_t *p_decoded_payload = NULL;

    decode_ra_message_payload( &ra_msg3, &p_decoded_payload, &decoded_payload_size );

    *p_msg3_size = decoded_payload_size - sizeof( ra_context_t );
    ra_msg3_t *p_msg3 = ( ra_msg3_t * ) calloc( *p_msg3_size, 1 );

    memcpy( p_msg3, p_decoded_payload, *p_msg3_size );
    memcpy( p_context, p_decoded_payload + *p_msg3_size, sizeof( ra_context_t ) );

    *pp_msg3 = p_msg3;
    return ret;
}

size_t ias_response_header_parser( void *ptr, size_t size,
                       size_t nmemb, void *userdata )
{
    int parsed_fields = 0, response_status, content_length, ret = size * nmemb;
    
    char *x = ( char * ) calloc( size + 1, nmemb );
    assert( x );
    memcpy( x, ptr, size * nmemb );
    parsed_fields = sscanf( x, "HTTP/1.1 %d", &response_status );
    if ( parsed_fields == 1 )
    {
        ( ( ias_response_header_t * ) userdata )->response_status = response_status;
        return ret;
    }

    parsed_fields = sscanf( x, "content-length: %d", &content_length );
    if ( parsed_fields == 1 ) 
    {   
        ( ( ias_response_header_t * ) userdata )->content_length = content_length;
        return ret;
    }

    char *p_request_id = ( char * ) calloc( 1, REQUEST_ID_MAX_LEN );
    parsed_fields = sscanf( x, "request-id: %s", p_request_id );
    if ( parsed_fields == 1 )
    {
        std::string request_id_str( p_request_id );
        ( ( ias_response_header_t * ) userdata )->request_id = request_id_str;
        return ret;
    }
    return ret;
}

size_t ias_reponse_body_handler( void *ptr, size_t size,
                       size_t nmemb, void *userdata )
{
    size_t realsize = size * nmemb;
    ias_response_container_t *ias_response_container = ( ias_response_container_t * ) userdata;
    ias_response_container->p_response = ( char * ) realloc( ias_response_container->p_response, ias_response_container->size + realsize + 1 );
    if ( ias_response_container->p_response == NULL )
    {
        fprintf( OUTPUT, "\nUnable to allocate extra memory\n" );
        return 0;
    }

    memcpy( &( ias_response_container->p_response[ ias_response_container->size ] ), ptr, realsize );
    ias_response_container->size += realsize;
    ias_response_container->p_response[ ias_response_container->size ] = 0;

    return realsize;
}

status_t retrieve_sig_rl_from_IAS( uint8_t **pp_sig_rl, uint32_t *p_sig_rl_size, epid_group_id_t gid )
{
    status_t ret = SUCCESS;

    ias_response_header_t response_header;
    ias_response_container_t ias_response_container;
    ias_response_container.p_response = ( char * ) malloc( 1 );
    ias_response_container.size = 0;

    CURL *curl;
    CURLcode res;

    static const char *p_cert_file = CERT_PATH;

    curl_global_init( CURL_GLOBAL_DEFAULT );

    curl = curl_easy_init( );
    if ( !curl )
    {
        fprintf( OUTPUT, "\nError when creating a curl handler [%s].\n",
                 __FUNCTION__ );
        return ERROR_UNEXPECTED;
    }
    char url[90];
    sprintf( url, "https://test-as.sgx.trustedservices.intel.com:443/attestation/sgx/v1/sigrl/%02x%02x%02x%02x", gid[3], gid[2], gid[1], gid[0] ); // Converting GID endianness
    curl_easy_setopt( curl, CURLOPT_URL, url );
    curl_easy_setopt( curl, CURLOPT_SSLCERTTYPE, "PEM" );
    curl_easy_setopt( curl, CURLOPT_SSLCERT, p_cert_file );
    curl_easy_setopt( curl, CURLOPT_USE_SSL, CURLUSESSL_ALL );
    curl_easy_setopt( curl, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2 );
    curl_easy_setopt( curl, CURLOPT_HEADERFUNCTION, ias_response_header_parser );
    curl_easy_setopt( curl, CURLOPT_HEADERDATA, &response_header );
    curl_easy_setopt( curl, CURLOPT_WRITEFUNCTION, ias_reponse_body_handler );
    curl_easy_setopt( curl, CURLOPT_WRITEDATA, &ias_response_container );
    curl_easy_setopt( curl, CURLOPT_NOPROGRESS, 1L);

    res = curl_easy_perform( curl );
    if ( res != CURLE_OK )
    {
        fprintf( stderr, "curl_easy_perform() failed: %s\n",
                curl_easy_strerror( res ) );
    }

    if ( response_header.content_length != ias_response_container.size )
    {
        fprintf( OUTPUT, "\nBody size differs from the one specified in the header [ %u %lu ]!\n", response_header.content_length, ias_response_container.size );
        ret = ERROR_UNEXPECTED;
    }

    size_t encoded_size = response_header.content_length;
    size_t sig_rl_size = encoded_size;
    uint8_t *p_sig_rl = ( uint8_t * ) malloc( sig_rl_size );
    memset( p_sig_rl, 0, sig_rl_size );

    if ( encoded_size > 0 ) base64decode( ias_response_container.p_response, encoded_size, p_sig_rl, &sig_rl_size );

    *pp_sig_rl = p_sig_rl;
    *p_sig_rl_size = sig_rl_size;

    curl_easy_cleanup( curl );
    curl_global_cleanup( );

    return ret;
}

bool verify_quote_with_IAS( char *p_encoded_quote, attestation_verification_report_t *p_avr )
{
#ifdef DEMO_VARIABLE
    fprintf( OUTPUT, "\nVerifying quote with IAS.. " );
#endif
    CURL *curl;
    CURLcode res;

    curl_global_init( CURL_GLOBAL_DEFAULT );

    curl = curl_easy_init( );
    if ( !curl )
    {
        fprintf( OUTPUT, "\nError when creating a curl handler [%s].\n",
                 __FUNCTION__ );
        return ERROR_UNEXPECTED;
    }

    // Request variables
    const char *url = "https://test-as.sgx.trustedservices.intel.com:443/attestation/sgx/v1/report";
    static const char *p_cert_file = CERT_PATH;
    std::string isv_enclave_quote( p_encoded_quote );
    attestation_evidence_payload_t aep{ isv_enclave_quote };
    const auto aep_json = jsoncpp::to_string( aep );

    struct curl_slist *headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/json");

    // Request setopt
    curl_easy_setopt( curl, CURLOPT_URL, url );
#ifdef DEBUG_VARIABLE
    curl_easy_setopt( curl, CURLOPT_VERBOSE, 1L );
#endif
    curl_easy_setopt( curl, CURLOPT_SSLCERTTYPE, "PEM" );
    curl_easy_setopt( curl, CURLOPT_SSLCERT, p_cert_file );
    curl_easy_setopt( curl, CURLOPT_USE_SSL, CURLUSESSL_ALL );
    curl_easy_setopt( curl, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2 );
    curl_easy_setopt( curl, CURLOPT_NOPROGRESS, 1L);
    curl_easy_setopt( curl, CURLOPT_HTTPHEADER, headers );
    curl_easy_setopt( curl, CURLOPT_POSTFIELDS, aep_json.c_str( ) );

    // Response variables
    ias_response_header_t response_header;

    ias_response_container_t ias_response_container;
    ias_response_container.p_response = ( char * ) malloc( 1 );
    ias_response_container.size = 0;

    // Response setopt
    curl_easy_setopt( curl, CURLOPT_HEADERFUNCTION, ias_response_header_parser );
    curl_easy_setopt( curl, CURLOPT_HEADERDATA, &response_header );
    curl_easy_setopt( curl, CURLOPT_WRITEFUNCTION, ias_reponse_body_handler );
    curl_easy_setopt( curl, CURLOPT_WRITEDATA, &ias_response_container );

    res = curl_easy_perform( curl );
    if ( res != CURLE_OK )
    {
        fprintf( stderr, "curl_easy_perform() failed: %s\n",
                curl_easy_strerror( res ) );
                return false;
    }
#ifdef DEMO_VARIABLE
    fprintf( OUTPUT, "\nResponse from IAS:\n%s\n", ias_response_container.p_response );
#endif
    // Build attestation verification report from response JSON
    attestation_verification_report_t avr;
    std::string avr_str( ias_response_container.p_response );
    jsoncpp::parse( avr, avr_str );
#ifdef DEMO_VARIABLE
    fprintf( OUTPUT, "\nVerifying isvEnclaveQuoteStatus.. " );
#endif    
    if ( avr.isv_enclave_quote_status.compare( "OK" ) != 0 )
    {
#ifdef DEMO_VARIABLE
        fprintf( OUTPUT, "[ FAIL ]\n" );
#endif
        fprintf( OUTPUT, "\nQuote has not been verified by IAS!\n" );
        return false;
    }
#ifdef DEMO_VARIABLE
    fprintf( OUTPUT, "[ OK ]\n" );
#endif
#ifdef DEBUG_VARIABLE
    fprintf( OUTPUT, "\nSuccessfully verified Quote with IAS\n" );
#endif
    p_avr->report_id = avr.report_id;
    p_avr->isv_enclave_quote_status = avr.isv_enclave_quote_status;
    p_avr->timestamp = avr.timestamp;

    return true;
}

SecByteBlock getSharedKey()
{
    char *p_publicKeySPHex;
    uint8_t *p_publicKeySP = (uint8_t *) calloc(sizeof(ec256_public_t), 1);
    memcpy(p_publicKeySP, &keys_db.g_a, sizeof(ec256_public_t));
    reverse(p_publicKeySP, ECP256_KEY_SIZE);
    reverse(p_publicKeySP+ECP256_KEY_SIZE, ECP256_KEY_SIZE);
    byteArrayToHexstr(p_publicKeySP, sizeof(ec256_public_t), &p_publicKeySPHex);
    string publicKeySPStr(p_publicKeySPHex);
    HexDecoder decoder;
    decoder.Put((byte *) publicKeySPStr.data(), publicKeySPStr.size());
    decoder.MessageEnd();

    ECP::Point q;
    size_t len = decoder.MaxRetrievable();
    q.identity = false;
    q.x.Decode(decoder, len/2);
    q.y.Decode(decoder, len/2);

    OID CURVE = secp256r1();
    DL_GroupParameters_EC<ECP> params(CURVE);

    size_t size = params.GetEncodedElementSize(true);
    vector<byte> publicKeySPbyteVector(size);
    params.EncodeElement(true, q, &publicKeySPbyteVector[0]);

    ECDH < ECP >::Domain dh( CURVE );
    if (dh.AgreedValueLength() != ECP256_KEY_SIZE) printf("Wrong shared key size!\n");
    SecByteBlock sharedKey(dh.AgreedValueLength());
    if (!dh.Agree(sharedKey, privateKeyClientBlock, &publicKeySPbyteVector[0])) printf("One or more invalid keys used!\n");

    SAFE_FREE(p_publicKeySP);
    SAFE_FREE(p_publicKeySPHex);

    return sharedKey;    
}

void compute_cmac(string key, uint8_t *plainData, size_t len, uint8_t *mac )
{
    CMAC<AES> cmac((byte *)key.data(), key.size());
    cmac.Update((const byte*) plainData, len);
    cmac.Final((byte *) mac);
}

void derive_key( uint8_t *p_sharedKeyBytesLE, const char* label, uint32_t label_length, ec_key_128bit_t* derived_key )
{
    ec_key_128bit_t key_derive_key;

    if (label_length > EC_DERIVATION_BUFFER_SIZE( label_length))
    {
        printf("Integer overflow. Aborting!\n");
        return;
    }
    string key0str, plaintext1, kdk;
    key0str = HexDecode("00000000 00000000 00000000 00000000");

    compute_cmac(key0str, p_sharedKeyBytesLE, MAC_KEY_SIZE*2, (uint8_t *) key_derive_key);
    
    char *p_kdkHex;
    byteArrayToHexstr((uint8_t *) key_derive_key, MAC_KEY_SIZE, &p_kdkHex);
    string kdkHexStr(p_kdkHex);
    string kdkStr = HexDecode(kdkHexStr.c_str());
    
    size_t derivation_buffer_length = EC_DERIVATION_BUFFER_SIZE( label_length );                                       
    uint8_t *p_derivation_buffer = ( uint8_t * ) calloc( derivation_buffer_length, 1 );

    p_derivation_buffer[0] = 0x01;
    memcpy(&p_derivation_buffer[ 1 ], label, label_length);
    uint16_t *key_len = ( uint16_t * ) &p_derivation_buffer[ derivation_buffer_length - 2 ];
    *key_len = 0x0080;

    compute_cmac(kdkStr, (uint8_t *) p_derivation_buffer, derivation_buffer_length, (uint8_t *) derived_key);
    memset(&key_derive_key, 0, sizeof(key_derive_key));
    SAFE_FREE(p_derivation_buffer);
}

void derive_keys()
{
    SecByteBlock sharedKey(getSharedKey());
    uint8_t *p_sharedKeyBytesLE = (uint8_t *) calloc(MAC_KEY_SIZE*2, 1);
    memcpy(p_sharedKeyBytesLE, sharedKey.data(), sharedKey.size());
    reverse(p_sharedKeyBytesLE, MAC_KEY_SIZE*2);
    
    derive_key( p_sharedKeyBytesLE, "SMK", (uint32_t)(sizeof("SMK")-1), &keys_db.smk_key);
    derive_key( p_sharedKeyBytesLE, "MK",  (uint32_t)(sizeof("MK")-1),  &keys_db.mk_key);
    derive_key( p_sharedKeyBytesLE, "SK",  (uint32_t)(sizeof("SK")-1),  &keys_db.sk_key);
    derive_key( p_sharedKeyBytesLE, "VK",  (uint32_t)(sizeof("VK")-1),  &keys_db.vk_key);

    SAFE_FREE(p_sharedKeyBytesLE);
}

status_t process_msg1( ra_msg1_t *p_msg1, ra_msg2_t **pp_msg2_out, uint32_t *p_msg2_size )
{
    status_t ret = SUCCESS, status = SUCCESS;

    memcpy( &keys_db.g_a, &p_msg1->g_a, PUBLIC_KEY_SIZE );
    derive_keys();

    uint8_t* sig_rl = NULL;
    uint32_t sig_rl_size = 0;

    ret = retrieve_sig_rl_from_IAS( &sig_rl, &sig_rl_size, p_msg1->gid );
    if ( SUCCESS != ret )
    {
        fprintf( OUTPUT, "\nSomething went wrong while retrieving SigRL from IAS!\n" );
        return ret;
    }

    uint32_t msg2_size = sizeof( ra_msg2_t ) + sig_rl_size;
    *p_msg2_size = msg2_size;

    ra_msg2_t *p_msg2 = ( ra_msg2_t * ) malloc( msg2_size );
    memset( p_msg2, 0, msg2_size );

    // g_b
    memcpy( &p_msg2->g_b, &keys_db.g_b, PUBLIC_KEY_SIZE );

    // SPID
    memcpy( &p_msg2->spid.id, &smart_meter_spid, SPID_SIZE );

    // Quote type
    p_msg2->quote_type = UNLINKABLE_SIGNATURE;

    // kdf_id
    p_msg2->kdf_id = 0x0001;

    // sign_gb_ga
    size_t gb_ga_size = 2*sizeof(ec256_public_t);
    ECDSA<ECP,SHA256>::Signer signer(privateKeyBigEndian);
    AutoSeededRandomPool prng;
    size_t siglen = signer.MaxSignatureLength();
    string signature(siglen, 0x00);
    siglen = signer.SignMessage( prng, ( const byte * ) &keys_db.g_b, gb_ga_size, (byte *)&p_msg2->sign_gb_ga );
    reverse( (uint8_t *)&p_msg2->sign_gb_ga, siglen/2 );
    reverse( ((uint8_t *)&p_msg2->sign_gb_ga)+siglen/2, siglen/2 );
    
    // MAC
    uint32_t plain_text_size = sizeof( ec256_public_t )     // g_b
                             + sizeof( spid_t )             // SPID
                             + sizeof( uint16_t )           // quote_type
                             + sizeof( uint16_t )           // kdf_id
                             + sizeof( ec256_signature_t ); // sign_gb_ga

    uint8_t *p_smk = (uint8_t *) calloc(sizeof(ra_key_128_t), 1);
    memcpy(p_smk, &keys_db.smk_key, sizeof(ra_key_128_t));

    char *p_smkHex;                                                                                                      
    byteArrayToHexstr(p_smk, MAC_KEY_SIZE, &p_smkHex);                                              
    string smkHexStr(p_smkHex);                                                                                          
    string smkStr = HexDecode(smkHexStr.c_str());
    
    compute_cmac(smkStr, (uint8_t *) p_msg2, plain_text_size, (uint8_t *) &p_msg2->mac );
    SAFE_FREE(p_smk);

    // sig_rl_size
    p_msg2->sig_rl_size = sig_rl_size;

    // sig_rl
    memcpy(&p_msg2->sig_rl[0], sig_rl, sig_rl_size);
    *pp_msg2_out = p_msg2;
    SAFE_FREE(sig_rl);
    return ret;
}

int retrieve_encoded_quote( ra_msg3_t *p_msg3, uint32_t msg3_size, char *p_encoded_quote, uint32_t *p_encoded_quote_size )
{
    
    uint32_t quote_size = msg3_size - offsetof( ra_msg3_t, quote );
    quote_t *p_quote = ( quote_t * ) calloc( quote_size, 1 );
    memcpy( p_quote, &p_msg3->quote, quote_size );
    int ret;
    ret = base64encode( p_quote, quote_size, p_encoded_quote, *p_encoded_quote_size );
    return ret;
}

/* Client main */
int main( int argc, char* argv[] )
{
    memset( &keys_db, 0, sizeof( keys_db_item_t ) );
    generateKeyPair( );
    status_t ret = SUCCESS, status = SUCCESS;

    /* Generate keypair for RA process */
    ec256_public_t client_public_key;
    memset( &client_public_key, 0, sizeof( ec256_public_t ) );
    memcpy( &client_public_key, &keys_db.g_b, sizeof( ec256_public_t ) );

    /* Request SP to initiate RA process */
    zmq::context_t ra_context(1);
    zmq::socket_t attestationSocket(ra_context, ZMQ_REQ);
    char server_address[ 90 ] = "tcp://localhost:8888", remote_attestation_url[ 90 ];
    if ( argc == 2 )
    {
        sprintf( server_address, "tcp://%s", argv[ 1 ]  );
    }
    
    attestationSocket.connect( server_address );
    
    message_t ra_init_message;
    generate_ra_init_message( &client_public_key, &ra_init_message );
    memset(&client_public_key, 0, sizeof(ec256_public_t));
    string ra_init_request_body = jsoncpp::to_string( ra_init_message );

    s_send( attestationSocket, ra_init_request_body );
    string response = s_recv( attestationSocket );

    ra_msg1_t msg1;
    ra_context_t context;
    ret = retrieve_msg1_from_response( response, &msg1, &context );
    
    /* Generating MSG2 */
    ra_msg2_t *p_msg2;
    uint32_t msg2_size;

    ret = process_msg1( &msg1, &p_msg2, &msg2_size );
    if ( SUCCESS != ret )
    {
        fprintf( OUTPUT, "\nFailed to generate MSG2. [%s]",
                 __FUNCTION__ );
        SAFE_FREE( p_msg2 );
        return ret;
    }

    /* Send MSG2 to SP */
    message_t ra_msg2_message;
    generate_msg2_message( p_msg2, msg2_size, &context, &ra_msg2_message );
    SAFE_FREE( p_msg2 );
    string ra_msg2_request_body = jsoncpp::to_string( ra_msg2_message );

    s_send( attestationSocket, ra_msg2_request_body );
    response = s_recv( attestationSocket );

    /*Retrieve MSG3 from response */

    ra_msg3_t *p_msg3 = NULL;
    uint32_t msg3_size;
    ret = retrieve_msg3_from_response( response, &p_msg3, &msg3_size,  &context );
    size_t mr_enclave_offset;
    mr_enclave_offset = offsetof(quote_t, report_body) + offsetof(report_body_t, mr_enclave);
    print_byte_array(((uint8_t *) p_msg3->quote) + mr_enclave_offset, 32);
    
    uint32_t quote_size = msg3_size * 2;
    char *p_encoded_quote = (char *) calloc( quote_size, 1 );
    retrieve_encoded_quote( p_msg3, msg3_size, p_encoded_quote, &quote_size );

    bool ra_result = false;
    attestation_verification_report_t avr;

    ra_result = verify_quote_with_IAS( p_encoded_quote, &avr );

    message_t ra_confirmation_message;
    string confirmation_body;

    if ( ra_result ) fprintf( OUTPUT, "\nSuccessfully verified QUOTE with IAS.\n" );
    else
    {
        fprintf(OUTPUT, "\nQUOTE is invalid!");
        goto CLEANUP;
    }
    generate_confirmation_message( ra_result, &context, &ra_confirmation_message );
    confirmation_body = jsoncpp::to_string(ra_confirmation_message);
    s_send( attestationSocket, confirmation_body );

    fprintf(OUTPUT, "\nRemote attestation process completed!\n");

CLEANUP:
    /* Cleaning up */
    SAFE_FREE( p_msg3 );
    SAFE_FREE( p_encoded_quote );
    return ret;
    
}

string HexDecode(const string& data)                                                                                     
{
    string result;
    StringSource ss(data, true /*pump all*/,
                    new HexDecoder(
                                   new StringSink(result)
                                   ) // HexDecoder
                    ); // StringSource
    return result;                                                                                                       
}
