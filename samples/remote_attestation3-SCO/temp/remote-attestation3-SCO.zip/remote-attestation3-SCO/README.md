# **Remote Attestation**

## **General Information**

This project has been tested on Ubuntu 14.04.
Intel SGX SDK Linux 1.7

## **Dependencies**

### **SGX driver**

Follow the instructions in the linux-sgx-driver project available [here](https://github.com/01org/linux-sgx-driver).

### **SGX SDK and PSW**

Follow the instructions in the linux-sgx project available [her](https://github.com/01org/linux-sgx).

### **GCC 5**
                                                                                                                         
```bash                                                                                                                  
sudo add-apt-repository ppa:ubuntu-toolchain-r/test                                                                      
sudo apt-get update                                                                                                      
sudo apt-get install g++-5                                                                                               
```                                                                                                                      
                                                                                                                         
### **ZeroMQ message queue library**
                                                                                                                         
```bash                                                                                                                  
sudo apt-get install libzmq3-dev
```                                                                                                                      
                                                                                                                         
### **Crypto++ cryptographic library**
                                                                                                                         
```bash                                                                                                                  
sudo apt-get install libcrypto++-dev                                                                                     
```                                                                                                                      
                                                                                                                         
### **Boost C++ libraries**
                                                                                                                         
```bash                                                                                                                  
sudo apt-get install libboost-dev libboost-chrono-dev libboost-system-dev                                                
```

## **Setup**
Edit the Client/app/app.cpp file on line 29 to set the certificate file used when registering with IAS.
Edit the Client/app/app.cpp file on line 50 to set the SPID received from IAS.

## **Building the project**
```bash
$ # Build Client
$ cd Client
$ make
$ # Build SP
$ cd ../SP
$ make SGX_MODE=HW SGX_DEBUG=1
$ cd ..
```

## Running the project (both SP and client running on the same host)

```bash
$ # Start SP
$ cd SP
$ ./service-provider &
$ cd ..
$ # Start Client
$ cd Client
$ ./client
```
